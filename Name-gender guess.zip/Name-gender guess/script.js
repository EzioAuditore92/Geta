$(document).ready(function() {
    $('#search-button').on('click', function(){
		var name = $('input[name="NameInput"]').val();

		$.ajax({
			url: 'https://api.genderize.io/?name=' + name,
			method: 'GET',
			success: function(data) {
				if(data.gender == null) {
					$('#error-msg').text('There is no information for selected name');
				}
				else {
					$('#error-msg').text('');
				$('.result').empty();
				$('.result').append('<div>Gender for name: ' + name + ' is: ' + data.gender + ' with probability: ' + data.probability*100 + '%</div>');
				}
			},
			error: function() {
				$('#error-msg').text('There is no information for selected name');
			}
		});
	});
});
